
interface Application {
	taskMake();
	taskClean();
	taskReplace();
}

export { Application }