/**
 *	Packman - The Asset Pipe Machine
 *	@author Patrik Forsberg
 *	@date 2016
 */

/// <reference path="typings/main.d.ts" />

"use strict";

import { Global, ResourceType } from "./global";
import { FileSystemHelper } from "./core/filesystem.helper";
import { ResourceConfiguration } from "./core/resource.configuration";
import { ResourceProcessor } from "./core/resource.processor";
import { Terminal } from "./core/terminal";

var StringHelper	= require('./utilities/string.helper').StringHelper;
var ArrayHelper		= require('./utilities/array.helper').ArrayHelper;

var walker      	= require('walk');
var fs          	= require('fs');
var path        	= require('path') ;
var jsonfile    	= require('jsonfile');

// Tasks
var gulp			= require('gulp');
var taskConcat		= require('gulp-concat');
var taskReplace		= require('gulp-replace');
var taskRename		= require('gulp-rename');
var taskSass		= require('gulp-sass');
var taskUglify		= require('gulp-uglify');
var taskMinify		= require('gulp-minify-css');
var plumber			= require('gulp-plumber');
var taskSourceMaps  = require('gulp-sourcemaps');
var taskScsslint	= require('gulp-scss-lint');

class PackmanApp {
	public appRootDirectory: string = "";
	resourceConfiguration: ResourceConfiguration;
	fileSystemHelper: FileSystemHelper;
	terminal: Terminal;
	
	constructor() {
		this.appRootDirectory = path.dirname(require.main.filename); 
		this.resourceConfiguration = new ResourceConfiguration();
		this.fileSystemHelper = new FileSystemHelper();
		this.terminal = new Terminal();
	}

	getResourceTypeFromString(resourceName: string) {
		var resourceType = ResourceType.Unknown;

		switch (resourceName.toLowerCase()) {
			case Global.RESOURCE_NAME_STYLESHEET:
				resourceType = ResourceType.Style
				break;
			case Global.RESOURCE_NAME_SCRIPT:
				resourceType = ResourceType.Script
				break;
		}
		
		return resourceType;
	}

	validateConfigValues(configData: any) {
	}

	useAbsolutePathForPart(part) {
		return part.absolutePath != undefined && part.absolutePath;
	}

	/**
	 * Quick and dirty parsing of command line parameters...
	 */
	parseParameters() {
		var parameters = process.argv.slice(2);
		
		if (parameters.length == 0) {
			this.terminal.echoScreamingError("Input parameters missing!")
		}
	}

	/**
	 * Application Entry point
	 */
	public execute() {
		var terminal = this.terminal;

		var commandLineArguments = this.parseParameters();
		var configurationFileName = "resource.main.config.json";
		var configuration = this.parseConfigurationFile(configurationFileName);
		
		//if ()
	}

	/**
	 * Read and verify the main configuration file, kick off the build process
	 */
	parseConfigurationFile(configurationFileName: string) {
		var self = this;
		var terminal = this.terminal;
		var configurationData: any;

		if (!this.fileSystemHelper.fileOrDirectoryExists(configurationFileName)) {
			this.terminal.echoScreamingError("Configuration file \"" + configurationFileName + "\" not found, aborting!");
			process.exit(1);
		}

		try {
			configurationData = jsonfile.readFileSync(configurationFileName);
		}
		catch (Exception) {
			this.terminal.echoScreamingError("Error readind configuration file, check file permissions");
		} 

		if (StringHelper.isNullOrEmpty(configurationData.configuration.root)) {
			terminal.echoWarning("No root path found in configuration file");
		}
		
		var rootDir = configurationData.root;
		console.log("Master root", rootDir);
		
		if (this.resourceConfiguration.validateConfiguration()) {
			this.parseResourceSections(configurationData.sections);
		}
	}
	
	parseResourceSections(resourceSections: any) {
		var self = this;
		resourceSections.forEach(function(section) {
			var sectionBundles = section.bundles;
			var resourceType = self.getResourceTypeFromString(section.type);
			self.terminal.echoStatus("Section type:", section.type);
			self.parseSectionBundles(this.appRootDirectory, sectionBundles, resourceType);
		});
	}
	
	getBundleRootDirectory(bundle: any): string {
		var bundleRootDirectory = bundle.bundleFilename;
		bundleRootDirectory = bundle.root != undefined ? bundle.root : this.appRootDirectory;

		/*
		if (StringHelper.isNullOrEmpty(bundleRoot)) {
			this.terminal.echoScreamingError('Output path for bundle "' + chalk.bold(bundle.name)
				+ '"bailing out! Run with ' + chalk.green.bold.underline('--force') + ' to ignore error.');
		}
		*/
		
				
		var bundlePath = bundle.bundlePath;
		var bundleFilename = bundle.bundleFilename;

		if (StringHelper.isNullOrEmpty(bundleFilename)) {
			this.terminal.echoError("Bundle filename is missing!");
		}

		return bundleRootDirectory;
	}

	verifyBundleData(bundle: any) : boolean {
		var terminal = this.terminal;
		terminal.echoStatus("Bundle Root", bundleRoot);
		terminal.echoStatus("Bundle Name", bundle.name);
		terminal.echoStatus("Bundle Output Filename", bundleFilename);		
	}

	parseSectionBundles(rootDir, bundles, resourceType) {
		var self = this;
		var terminal = this.terminal;

		var bundleCount = bundles.length;
		var bundleCountSuffix = bundleCount != 1 ? "bundles" : "bundle";
		console.log(chalk.green.bold(bundleCount + ' ' +  bundleCountSuffix + 'found, Packman is on the case!'));

		for (var i = 0; i < bundleCount; i++) {
			var bundle = bundles[i];
			var bundleRoot = this.getBundleRootDirectory(bundle.root);
			
			terminal.echoInfo("Parsing bundle, using root: " + bundleRoot);
			
			var bundlePath = bundle.bundlePath;
			var bundleFilename = bundle.bundleFilename;

			var filesInBundle = [];
			var preservedPartsOrder = [];

			// Extracts filenames... 
			self.parseBundleParts(bundleRoot, bundle.parts, filesInBundle, preservedPartsOrder);

			/**
			 *	2016-04-07 
			 *	FIX: Added an extra stage in the bundling process to enable bundling of
			 *	assets generated in the same scope..
			 * 
			 *	TODO: Add cleanup functionality to remove compiled resources when
			 *	the final bundling is done...
			 *
			 */
			switch (resourceType) {
				case ResourceType.Script:
					self.compileScripts(bundleFilename, bundlePath, filesInBundle);
					//self.bundleScripts(bundleFilename, bundlePath, filesInBundle);
					break;

				case ResourceType.Style:
					//self.bundleStyles(bundleFilename, bundlePath, filesInBundle);
					break;
				
			}
		}
	}
	
	/************************************************************
	 * 
	 * 
	 *				   PROCESS AND BUILD ASSETS
	 * 
	 * 
	 ***********************************************************/
	compileScriptBundle(targetFilename: string, bundleOutputPath: string, filesInBundle: string[]) {
		
	}

	/**
	 * 
	 */
	compileScripts(bundleFilename, bundlePath, filesInBundle) {
	
	}

	/**
	 * 
	 */
	bundleScripts(bundleFilename, bundlePath, filesInBundle) {
		this.terminal.echoStatus("Compiling Scripts bundle to:", bundleFilename);
		gulp.src(filesInBundle)
			.pipe(taskConcat(bundleFilename))
			//.pipe(taskUglify())
			.pipe(gulp.dest(bundlePath));
	}
	
	/* Source map generation
	.pipe(sourcemaps.init())
	.pipe(taskSass().on('error', this.processorTaskError))
	.pipe(sourcemaps.write())
	*/

	bundleStyles(bundleFilename, bundlePath, filesInBundle) {
		this.terminal.echoStatus("Compiling Styles bundle to:", bundleFilename);
		gulp.src(filesInBundle)
			.pipe(taskSass().on('error', function(error) {
				console.log("SASS ERROR", error.message);
			}))
			.pipe(taskConcat(bundleFilename))
			.pipe(taskMinify())
			.pipe(gulp.dest(bundlePath));
	}

	filterFiles(fileList: string[], ignoreList: string[]) {
		fileList.forEach(function(file) {
			//console.log("filterFiles", "EXT: " + path.extname(file) + " : " + file);
		});
	}
	
	parseBundleParts(bundleRoot: string, bundleParts: any,
		filesInBundle: string[], preservedPartsOrder: string[]) {
		
		var self = this;
		bundleParts.forEach(function(part) {
			var partSource = "";
			
			if (self.useAbsolutePathForPart(part)) {
				partSource = part.src;
			} else {
				partSource = path.join(bundleRoot, part.src);
			}

			if (fs.existsSync(partSource)) {
				preservedPartsOrder.push(partSource);
				var stats = fs.lstatSync(partSource);
				
				var files = [];
				
				if (stats.isDirectory()) {
					files = self.fileSystemHelper.getFilesInDirectory(partSource);
				} else if (stats.isFile()) {
					files = [partSource];
				}

				//* TODO: This should not be needed, ignored files should
				//* never be added in the first
				self.filterFiles(files, []);

				ArrayHelper.arrayMerge(filesInBundle, files);
			} else {
				self.terminal.echoMissingFileError(partSource);
			}
		});		
	}
}

var packman = new PackmanApp();
packman.execute();
