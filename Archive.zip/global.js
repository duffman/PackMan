/**
 *	Packman - The Asset Machine
 *	@author Patrik Forsberg
 *	@date 2016-03-26
 */
"use strict";
var WalkOperationEvent;
(function (WalkOperationEvent) {
    WalkOperationEvent[WalkOperationEvent["Names"] = 0] = "Names";
    WalkOperationEvent[WalkOperationEvent["Directory"] = 1] = "Directory";
    WalkOperationEvent[WalkOperationEvent["Directories"] = 2] = "Directories";
    WalkOperationEvent[WalkOperationEvent["File"] = 3] = "File";
    WalkOperationEvent[WalkOperationEvent["Files"] = 4] = "Files";
    WalkOperationEvent[WalkOperationEvent["End"] = 5] = "End";
    WalkOperationEvent[WalkOperationEvent["NodeError"] = 6] = "NodeError";
    WalkOperationEvent[WalkOperationEvent["DirectoryError"] = 7] = "DirectoryError";
    WalkOperationEvent[WalkOperationEvent["Errors"] = 8] = "Errors";
})(WalkOperationEvent || (WalkOperationEvent = {}));
var ResourceType;
(function (ResourceType) {
    ResourceType[ResourceType["Unknown"] = 0] = "Unknown";
    ResourceType[ResourceType["Style"] = 1] = "Style";
    ResourceType[ResourceType["Script"] = 2] = "Script";
})(ResourceType || (ResourceType = {}));
exports.ResourceType = ResourceType;
class Global {
}
Global.CONFIG_FILE = "packman-config.json";
Global.Debug = true;
Global.RESOURCE_NAME_STYLESHEET = "style";
Global.RESOURCE_NAME_SCRIPT = "script";
// Resource Machine Task Names
Global.TASK_MAKE = "make";
Global.TASK_CLEAN = "clean";
Global.TASK_REPLACE = "replace";
exports.Global = Global;
//# sourceMappingURL=global.js.map