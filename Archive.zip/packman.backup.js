/**
 *	Packman - The Asset Pipe Machine
 *	@author Patrik Forsberg
 *	@date 2016
 */
/// <reference path="typings/main.d.ts" />
"use strict";
const global_1 = require("./global");
const filesystem_helper_1 = require("./core/filesystem.helper");
const terminal_1 = require("./core/terminal");
var StringHelper = require('./utilities/string.helper').StringHelper;
var ArrayHelper = require('./utilities/array.helper').ArrayHelper;
var walker = require('walk');
var fs = require('fs');
var path = require('path');
var jsonfile = require('jsonfile');
var chalk = require('chalk');
// Tasks
var gulp = require('gulp');
var taskConcat = require('gulp-concat');
var taskReplace = require('gulp-replace');
var taskRename = require('gulp-rename');
var taskSass = require('gulp-sass');
var taskUglify = require('gulp-uglify');
var taskMinify = require('gulp-minify-css');
var plumber = require('gulp-plumber');
var taskSourceMaps = require('gulp-sourcemaps');
var taskScsslint = require('gulp-scss-lint');
class PackmanApp {
    constructor() {
        this.fileSystemHelper = new filesystem_helper_1.FileSystemHelper();
        this.terminal = new terminal_1.Terminal();
    }
    getResourceTypeFromString(resourceName) {
        var resourceType = global_1.ResourceType.Unknown;
        switch (resourceName.toLowerCase()) {
            case global_1.Global.RESOURCE_NAME_STYLESHEET:
                resourceType = global_1.ResourceType.Style;
                break;
            case global_1.Global.RESOURCE_NAME_SCRIPT:
                resourceType = global_1.ResourceType.Script;
                break;
        }
        return resourceType;
    }
    validateConfigValues(configData) {
    }
    useAbsolutePathForPart(part) {
        return part.absolutePath != undefined && part.absolutePath;
    }
    test() {
        var extensionsRulesMask = "*.js, , *.html, *.css, *.exe";
        var extensionRules = extensionsRulesMask.split(",");
        for (var rule in extensionRules) {
            rule = rule.trim();
            if (StringHelper.isNullOrEmpty(rule)) {
                continue;
            }
            // Ignore all file extensions filter
            // at least 1 char is required for extension
            if (rule.startsWith("*.") && rule.length > 2) {
            }
        }
    }
    /**
     * Quick and dirty parsing of command line parameters...
     */
    parseParameters() {
        var parameters = process.argv.slice(2);
        if (parameters.length == 0) {
            this.terminal.echoScreamingError("Input parameters missing!");
        }
    }
    execute() {
        var terminal = this.terminal;
        var commandLineArguments = this.parseParameters();
        var configurationFileName = "resource.main.config.json";
        if (!this.fileSystemHelper.fileOrDirectoryExists(configurationFileName)) {
            this.terminal.echoError("Configuration file \"" + configurationFileName + "\" not found, aborting!");
            process.exit(1);
        }
        this.readConfig(configurationFileName);
    }
    /**
     * Read the asset build machibe configuration and
     * execute tasks accordingly
     */
    readConfig(configurationFileName) {
        var self = this;
        var errorLog = [];
        var configuration = jsonfile.readFileSync(configurationFileName);
        var rootDir = configuration.root;
        this.validateConfigValues(configuration);
        configuration.sections.forEach(function (section) {
            var sectionBundles = section.bundles;
            var resourceType = self.getResourceTypeFromString(section.type);
            self.terminal.echoStatus("Section type:", section.type);
            self.parseSectionBundles(rootDir, sectionBundles, resourceType);
        });
    }
    parseSectionBundles(rootDir, bundles, resourceType) {
        var self = this;
        var terminal = this.terminal;
        var bundleCount = bundles.length;
        var bundleCountSuffix = bundleCount != 1 ? "bundles" : "bundle";
        console.log(chalk.green.bold(bundleCount + ' ' + bundleCountSuffix + 'found, Packman is on the case!'));
        for (var i = 0; i < bundleCount; i++) {
            var bundle = bundles[i];
            var bundleRoot = bundle.root != undefined ? bundle.root : rootDir;
            var bundlePath = bundle.bundlePath;
            var bundleFilename = bundle.bundleFilename;
            if (StringHelper.isNullOrEmpty(bundleRoot)) {
                this.terminal.echoScreamingError('Output path for bundle "' + chalk.bold(bundle.name)
                    + '"bailing out! Run with ' + chalk.green.bold.underline('--force') + ' to ignore error.');
                continue;
            }
            if (StringHelper.isNullOrEmpty(bundleFilename)) {
                terminal.echoError("Bundle filename is missing!");
                continue;
            }
            terminal.echoStatus("Bundle Root", bundleRoot);
            terminal.echoStatus("Bundle Name", bundle.name);
            terminal.echoStatus("Bundle Output Filename", bundleFilename);
            var filesInBundle = [];
            var preservedPartsOrder = [];
            self.parseBundleParts(bundleRoot, bundle.parts, filesInBundle, preservedPartsOrder);
            switch (resourceType) {
                case global_1.ResourceType.Script:
                    self.bundleScripts(bundleFilename, bundlePath, filesInBundle);
                    break;
                case global_1.ResourceType.Style:
                    self.bundleStyles(bundleFilename, bundlePath, filesInBundle);
                    break;
            }
        }
    }
    /************************************************************
     *
     *
     * 				BUILD RESOURCES
     *
     *
     ***********************************************************/
    bundleScripts(bundleFilename, bundlePath, filesInBundle) {
        this.terminal.echoStatus("Compiling Scripts bundle to:", bundleFilename);
        gulp.src(filesInBundle)
            .pipe(taskConcat(bundleFilename))
            .pipe(gulp.dest(bundlePath));
    }
    /* Source map generation
    .pipe(sourcemaps.init())
    .pipe(taskSass().on('error', this.processorTaskError))
    .pipe(sourcemaps.write())
    */
    bundleStyles(bundleFilename, bundlePath, filesInBundle) {
        this.terminal.echoStatus("Compiling Styles bundle to:", bundleFilename);
        gulp.src(filesInBundle)
            .pipe(taskSass().on('error', function (error) {
            console.log("SASS ERROR", error.message);
        }))
            .pipe(taskConcat(bundleFilename))
            .pipe(taskMinify())
            .pipe(gulp.dest(bundlePath));
    }
    filterFiles(fileList, ignoreList) {
        fileList.forEach(function (file) {
            //console.log("filterFiles", "EXT: " + path.extname(file) + " : " + file);
        });
    }
    parseBundleParts(bundleRoot, bundleParts, filesInBundle, preservedPartsOrder) {
        var self = this;
        bundleParts.forEach(function (part) {
            var partSource = "";
            if (self.useAbsolutePathForPart(part)) {
                partSource = part.src;
            }
            else {
                partSource = path.join(bundleRoot, part.src);
            }
            if (fs.existsSync(partSource)) {
                preservedPartsOrder.push(partSource);
                var stats = fs.lstatSync(partSource);
                var files = [];
                if (stats.isDirectory()) {
                    files = self.fileSystemHelper.getFilesInDirectory(partSource);
                }
                else if (stats.isFile()) {
                    files = [partSource];
                }
                //* TODO: This should not be needed, ignored files should
                //* never be added in the first
                self.filterFiles(files, []);
                ArrayHelper.arrayMerge(filesInBundle, files);
            }
            else {
                self.terminal.echoMissingFileError(partSource);
            }
        });
    }
}
var packman = new PackmanApp();
packman.execute();
//# sourceMappingURL=packman.backup.js.map