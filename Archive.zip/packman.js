/**
 *	Packman - The Asset Pipe Machine
 *	@author Patrik Forsberg
 *	@date 2016
 */
/// <reference path="typings/main.d.ts" />
"use strict";
const global_1 = require("./global");
const filesystem_helper_1 = require("./core/filesystem.helper");
const resource_configuration_1 = require("./core/resource.configuration");
const terminal_1 = require("./core/terminal");
var StringHelper = require('./utilities/string.helper').StringHelper;
var ArrayHelper = require('./utilities/array.helper').ArrayHelper;
var walker = require('walk');
var fs = require('fs');
var path = require('path');
var jsonfile = require('jsonfile');
// Tasks
var gulp = require('gulp');
var taskConcat = require('gulp-concat');
var taskReplace = require('gulp-replace');
var taskRename = require('gulp-rename');
var taskSass = require('gulp-sass');
var taskUglify = require('gulp-uglify');
var taskMinify = require('gulp-minify-css');
var plumber = require('gulp-plumber');
var taskSourceMaps = require('gulp-sourcemaps');
var taskScsslint = require('gulp-scss-lint');
class PackmanApp {
    constructor() {
        this.appRootDirectory = "";
        this.appRootDirectory = path.dirname(require.main.filename);
        this.resourceConfiguration = new resource_configuration_1.ResourceConfiguration();
        this.fileSystemHelper = new filesystem_helper_1.FileSystemHelper();
        this.terminal = new terminal_1.Terminal();
    }
    getResourceTypeFromString(resourceName) {
        var resourceType = global_1.ResourceType.Unknown;
        switch (resourceName.toLowerCase()) {
            case global_1.Global.RESOURCE_NAME_STYLESHEET:
                resourceType = global_1.ResourceType.Style;
                break;
            case global_1.Global.RESOURCE_NAME_SCRIPT:
                resourceType = global_1.ResourceType.Script;
                break;
        }
        return resourceType;
    }
    validateConfigValues(configData) {
    }
    useAbsolutePathForPart(part) {
        return part.absolutePath != undefined && part.absolutePath;
    }
    /**
     * Quick and dirty parsing of command line parameters...
     */
    parseParameters() {
        var parameters = process.argv.slice(2);
        if (parameters.length == 0) {
            this.terminal.echoScreamingError("Input parameters missing!");
        }
    }
    /**
     * Application Entry point
     */
    execute() {
        var terminal = this.terminal;
        var commandLineArguments = this.parseParameters();
        var configurationFileName = "resource.main.config.json";
        var configuration = this.parseConfigurationFile(configurationFileName);
        //if ()
    }
    /**
     * Read and verify the main configuration file, kick off the build process
     */
    parseConfigurationFile(configurationFileName) {
        var self = this;
        var terminal = this.terminal;
        var configurationData;
        if (!this.fileSystemHelper.fileOrDirectoryExists(configurationFileName)) {
            this.terminal.echoScreamingError("Configuration file \"" + configurationFileName + "\" not found, aborting!");
            process.exit(1);
        }
        try {
            configurationData = jsonfile.readFileSync(configurationFileName);
        }
        catch (Exception) {
            this.terminal.echoScreamingError("Error readind configuration file, check file permissions");
        }
        if (StringHelper.isNullOrEmpty(configurationData.configuration.root)) {
            terminal.echoWarning("No root path found in configuration file");
        }
        var rootDir = configurationData.root;
        console.log("Master root", rootDir);
        if (this.resourceConfiguration.validateConfiguration()) {
            this.parseResourceSections(configurationData.sections);
        }
    }
    parseResourceSections(resourceSections) {
        var self = this;
        resourceSections.forEach(function (section) {
            var sectionBundles = section.bundles;
            var resourceType = self.getResourceTypeFromString(section.type);
            self.terminal.echoStatus("Section type:", section.type);
            self.parseSectionBundles(this.appRootDirectory, sectionBundles, resourceType);
        });
    }
    getBundleRootDirectory(bundle) {
        var bundleRootDirectory = bundle.bundleFilename;
        bundleRootDirectory = bundle.root != undefined ? bundle.root : this.appRootDirectory;
        /*
        if (StringHelper.isNullOrEmpty(bundleRoot)) {
            this.terminal.echoScreamingError('Output path for bundle "' + chalk.bold(bundle.name)
                + '"bailing out! Run with ' + chalk.green.bold.underline('--force') + ' to ignore error.');
        }
        */
        var bundlePath = bundle.bundlePath;
        var bundleFilename = bundle.bundleFilename;
        if (StringHelper.isNullOrEmpty(bundleFilename)) {
            this.terminal.echoError("Bundle filename is missing!");
        }
        return bundleRootDirectory;
    }
    verifyBundleData(bundle) {
        var terminal = this.terminal;
        terminal.echoStatus("Bundle Root", bundleRoot);
        terminal.echoStatus("Bundle Name", bundle.name);
        terminal.echoStatus("Bundle Output Filename", bundleFilename);
    }
    parseSectionBundles(rootDir, bundles, resourceType) {
        var self = this;
        var terminal = this.terminal;
        var bundleCount = bundles.length;
        var bundleCountSuffix = bundleCount != 1 ? "bundles" : "bundle";
        console.log(chalk.green.bold(bundleCount + ' ' + bundleCountSuffix + 'found, Packman is on the case!'));
        for (var i = 0; i < bundleCount; i++) {
            var bundle = bundles[i];
            var bundleRoot = this.getBundleRootDirectory(bundle.root);
            terminal.echoInfo("Parsing bundle, using root: " + bundleRoot);
            var bundlePath = bundle.bundlePath;
            var bundleFilename = bundle.bundleFilename;
            var filesInBundle = [];
            var preservedPartsOrder = [];
            // Extracts filenames... 
            self.parseBundleParts(bundleRoot, bundle.parts, filesInBundle, preservedPartsOrder);
            /**
             *	2016-04-07
             *	FIX: Added an extra stage in the bundling process to enable bundling of
             *	assets generated in the same scope..
             *
             *	TODO: Add cleanup functionality to remove compiled resources when
             *	the final bundling is done...
             *
             */
            switch (resourceType) {
                case global_1.ResourceType.Script:
                    self.compileScripts(bundleFilename, bundlePath, filesInBundle);
                    //self.bundleScripts(bundleFilename, bundlePath, filesInBundle);
                    break;
                case global_1.ResourceType.Style:
                    //self.bundleStyles(bundleFilename, bundlePath, filesInBundle);
                    break;
            }
        }
    }
    /************************************************************
     *
     *
     *				   PROCESS AND BUILD ASSETS
     *
     *
     ***********************************************************/
    compileScriptBundle(targetFilename, bundleOutputPath, filesInBundle) {
    }
    /**
     *
     */
    compileScripts(bundleFilename, bundlePath, filesInBundle) {
    }
    /**
     *
     */
    bundleScripts(bundleFilename, bundlePath, filesInBundle) {
        this.terminal.echoStatus("Compiling Scripts bundle to:", bundleFilename);
        gulp.src(filesInBundle)
            .pipe(taskConcat(bundleFilename))
            .pipe(gulp.dest(bundlePath));
    }
    /* Source map generation
    .pipe(sourcemaps.init())
    .pipe(taskSass().on('error', this.processorTaskError))
    .pipe(sourcemaps.write())
    */
    bundleStyles(bundleFilename, bundlePath, filesInBundle) {
        this.terminal.echoStatus("Compiling Styles bundle to:", bundleFilename);
        gulp.src(filesInBundle)
            .pipe(taskSass().on('error', function (error) {
            console.log("SASS ERROR", error.message);
        }))
            .pipe(taskConcat(bundleFilename))
            .pipe(taskMinify())
            .pipe(gulp.dest(bundlePath));
    }
    filterFiles(fileList, ignoreList) {
        fileList.forEach(function (file) {
            //console.log("filterFiles", "EXT: " + path.extname(file) + " : " + file);
        });
    }
    parseBundleParts(bundleRoot, bundleParts, filesInBundle, preservedPartsOrder) {
        var self = this;
        bundleParts.forEach(function (part) {
            var partSource = "";
            if (self.useAbsolutePathForPart(part)) {
                partSource = part.src;
            }
            else {
                partSource = path.join(bundleRoot, part.src);
            }
            if (fs.existsSync(partSource)) {
                preservedPartsOrder.push(partSource);
                var stats = fs.lstatSync(partSource);
                var files = [];
                if (stats.isDirectory()) {
                    files = self.fileSystemHelper.getFilesInDirectory(partSource);
                }
                else if (stats.isFile()) {
                    files = [partSource];
                }
                //* TODO: This should not be needed, ignored files should
                //* never be added in the first
                self.filterFiles(files, []);
                ArrayHelper.arrayMerge(filesInBundle, files);
            }
            else {
                self.terminal.echoMissingFileError(partSource);
            }
        });
    }
}
var packman = new PackmanApp();
packman.execute();
//# sourceMappingURL=packman.js.map